// DOM Elements
const userAvatar = document.getElementById('user-avatar');
const username = document.getElementById('username');
const userStatus = document.getElementById('user-status');
const totalFriends = document.getElementById('total-friends');
const addedCount = document.getElementById('added-count');
const deletedCount = document.getElementById('deleted-count');
const lastCheck = document.getElementById('last-check');

const changesTab = document.getElementById('changes-tab');
const historyTab = document.getElementById('history-tab');
const noChanges = document.getElementById('no-changes');
const changesList = document.getElementById('changes-list');
const noHistory = document.getElementById('no-history');
const historyList = document.getElementById('history-list');

const addedSection = document.getElementById('added-section');
const deletedSection = document.getElementById('deleted-section');
const addedListEl = document.getElementById('added-list');
const deletedListEl = document.getElementById('deleted-list');

const refreshBtn = document.getElementById('refresh-btn');
const clearBtn = document.getElementById('clear-btn');
const tabBtns = document.querySelectorAll('.tab-btn');

// Access token for Facebook Graph API (backup)
const FB_ACCESS_TOKEN = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662";

// Alternative Graph API approach without token
const getFacebookAvatar = (uid) => {
    // Try multiple avatar URLs
    const avatarUrls = [
        `https://graph.facebook.com/${uid}/picture?type=square&width=50&height=50`,
        `https://graph.facebook.com/${uid}/picture?type=small`,
        `https://graph.facebook.com/${uid}/picture`,
        `https://www.facebook.com/tr?id=${uid}&ev=PageView&noscript=1`
    ];
    
    return avatarUrls[0]; // Use first as primary
};

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 Popup initialized, starting load...');
    try {
        await loadUserData();
        setupEventListeners();
        showTab('changes'); // Default tab
        console.log('✅ Popup setup completed');
    } catch (error) {
        console.error('❌ Popup initialization failed:', error);
        showError();
    }
});

// Event Listeners
function setupEventListeners() {
    console.log('🔧 Setting up event listeners...');
    
    // Tab switching
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.dataset.tab;
            console.log('📑 Switching to tab:', tabName);
            showTab(tabName);
        });
    });

    // Refresh button
    refreshBtn.addEventListener('click', async () => {
        console.log('🔄 Deep scan button clicked');
        refreshBtn.disabled = true;
        refreshBtn.innerHTML = '🔄 Scanning... <span class="loading"></span>';
        userStatus.textContent = 'Deep scanning friends list...';
        
        try {
            console.log('📡 Sending CheckNow message to background...');
            const response = await chrome.runtime.sendMessage({ action: 'CheckNow' });
            console.log('📡 Background response:', response);
            
            console.log('⏳ Waiting for scan to complete...');
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            console.log('📊 Reloading user data...');
            await loadUserData();
            userStatus.textContent = 'Scan completed!';
            console.log('✅ Deep scan completed successfully');
        } catch (error) {
            console.error('❌ Error during deep scan:', error);
            userStatus.textContent = 'Error during scan. Try again.';
        } finally {
            refreshBtn.disabled = false;
            refreshBtn.innerHTML = '🔄 Deep Scan';
        }
    });

    // Clear history button
    clearBtn.addEventListener('click', async () => {
        console.log('🗑️ Clear history button clicked');
        if (confirm('Are you sure you want to clear all history?')) {
            try {
                console.log('🧹 Clearing history...');
                await chrome.storage.local.set({ 
                    history: { list: [] },
                    pending: { added: [], deleted: [], friendsTemp: {} }
                });
                await loadUserData();
                userStatus.textContent = 'History cleared';
                console.log('✅ History cleared successfully');
            } catch (error) {
                console.error('❌ Error clearing history:', error);
            }
        }
    });
    
    console.log('✅ Event listeners setup completed');
}

// Load user data from background
async function loadUserData() {
    console.log('📥 Loading user data from background...');
    try {
        // Get data from background script
        console.log('📡 Sending GetResults message...');
        const response = await chrome.runtime.sendMessage({ action: 'GetResults' });
        
        console.log('📦 Full extension response:', response);
        
        if (!response) {
            console.log('❌ No response from background script');
            showError();
            return;
        }
        
        if (!response.payload) {
            console.log('⚠️ No payload found, user might not be logged in');
            console.log('📊 Response structure:', Object.keys(response));
            showLoginRequired();
            return;
        }

        console.log('👤 User payload received:', response.payload);
        console.log('📊 Payload structure:', Object.keys(response.payload));
        
        updateUserInfo(response.payload);
        updateStats(response);
        updateChanges(response.pending || {});
        updateHistory(response.history || { list: [] });
        updateLastCheck();
        
        console.log('✅ User data loaded successfully');
        
    } catch (error) {
        console.error('❌ Error loading user data:', error);
        console.error('❌ Error stack:', error.stack);
        showError();
    }
}

// Show login required message
function showLoginRequired() {
    console.log('User not logged in to Facebook');
    username.textContent = 'Please log in to Facebook';
    userStatus.textContent = 'Open Facebook in a new tab and log in';
    userAvatar.src = './icons/ic_48.png';
    
    // Show no data messages
    noChanges.querySelector('p').textContent = 'Please log in to Facebook first';
    noChanges.querySelector('small').textContent = 'Open facebook.com and log in, then click Deep Scan';
    
    noHistory.querySelector('p').textContent = 'Please log in to Facebook';
    noHistory.querySelector('small').textContent = 'History will be available after logging in';
    
    // Add login button functionality
    refreshBtn.innerHTML = '🔓 Login Required';
    refreshBtn.onclick = () => {
        chrome.tabs.create({ url: 'https://facebook.com' });
    };
}

// Show error message
function showError() {
    username.textContent = 'Error';
    userStatus.textContent = 'Unable to load data. Please try again.';
    userAvatar.src = './icons/ic_48.png';
}

// Update user info
function updateUserInfo(payload) {
    console.log('👤 Updating user info with payload:', payload);
    console.log('📊 Payload keys:', Object.keys(payload));
    
    const userName = payload.name || 'Unknown User';
    username.textContent = userName;
    userStatus.textContent = 'Monitoring Facebook changes';
    
    console.log('👤 User name set to:', userName);
    
    // Try multiple avatar sources with fallback chain
    if (payload.photo && payload.photo !== '' && payload.photo !== 'undefined') {
        console.log('🖼️ Using payload photo:', payload.photo);
        userAvatar.src = payload.photo;
    } else if (payload.uid && payload.uid !== '' && payload.uid !== 'undefined') {
        console.log('🖼️ Using Facebook Graph API for UID:', payload.uid);
        const avatarUrl = getFacebookAvatar(payload.uid);
        console.log('🖼️ Avatar URL:', avatarUrl);
        userAvatar.src = avatarUrl;
    } else {
        console.log('🖼️ No avatar source available, using default icon');
        userAvatar.src = './icons/ic_48.png';
    }
    
    // Handle avatar load errors with fallback chain
    userAvatar.onerror = function() {
        console.log('❌ Avatar failed to load:', this.src);
        
        // If Graph API failed, try with access token
        if (this.src.includes('graph.facebook.com') && !this.src.includes('access_token') && payload.uid) {
            console.log('🔄 Trying with access token...');
            this.src = `https://graph.facebook.com/${payload.uid}/picture?type=square&access_token=${FB_ACCESS_TOKEN}`;
        } else {
            console.log('🔄 All avatar sources failed, using default icon');
            this.src = './icons/ic_48.png';
            // Prevent infinite loop
            this.onerror = null;
        }
    };
    
    // Handle avatar load success
    userAvatar.onload = function() {
        console.log('✅ Avatar loaded successfully:', this.src);
    };
    
    console.log('✅ User info update completed');
}

// Update stats
function updateStats(data) {
    console.log('📊 Updating stats with data:', data);
    const { payload, pending } = data;
    
    if (payload && payload.friends) {
        const detectedCount = Object.keys(payload.friends).length;
        totalFriends.textContent = detectedCount;
        
        console.log('👥 Total friends detected:', detectedCount);
        console.log('👥 Friends object keys:', Object.keys(payload.friends).slice(0, 5), '...');
        
        // Add tooltip hint about potential difference
        totalFriends.parentElement.title = `Detected friends: ${detectedCount}\nNote: May differ from Facebook count due to privacy settings`;
    } else {
        console.log('⚠️ No friends data in payload');
        totalFriends.textContent = '0';
    }
    
    if (pending) {
        const addedCount = pending.added ? pending.added.length : 0;
        const deletedCount = pending.deleted ? pending.deleted.length : 0;
        
        console.log('➕ Added friends count:', addedCount);
        console.log('➖ Deleted friends count:', deletedCount);
        
        if (addedCount > 0) {
            console.log('➕ Added friends:', pending.added);
        }
        if (deletedCount > 0) {
            console.log('➖ Deleted friends:', pending.deleted);
        }
        
        document.getElementById('added-count').textContent = addedCount;
        document.getElementById('deleted-count').textContent = deletedCount;
    } else {
        console.log('📊 No pending changes');
        document.getElementById('added-count').textContent = '0';
        document.getElementById('deleted-count').textContent = '0';
    }
    
    console.log('✅ Stats update completed');
}

// Update changes tab
function updateChanges(pending) {
    const hasAdded = pending.added && pending.added.length > 0;
    const hasDeleted = pending.deleted && pending.deleted.length > 0;
    
    if (!hasAdded && !hasDeleted) {
        noChanges.style.display = 'block';
        changesList.style.display = 'none';
        return;
    }
    
    noChanges.style.display = 'none';
    changesList.style.display = 'block';
    
    // Show added friends
    if (hasAdded) {
        addedSection.style.display = 'block';
        addedListEl.innerHTML = '';
        
        pending.added.forEach(uid => {
            const friend = pending.friendsTemp && pending.friendsTemp[uid];
            if (friend) {
                addedListEl.appendChild(createFriendItem(friend, 'added', 'Just now'));
            }
        });
    } else {
        addedSection.style.display = 'none';
    }
    
    // Show deleted friends
    if (hasDeleted) {
        deletedSection.style.display = 'block';
        deletedListEl.innerHTML = '';
        
        pending.deleted.forEach(uid => {
            // Get friend info from main friends list
            const friend = { uid, name: 'Unknown User', photo: './icons/ic_32.png' };
            deletedListEl.appendChild(createFriendItem(friend, 'deleted', 'Just now'));
        });
    } else {
        deletedSection.style.display = 'none';
    }
}

// Update history tab
function updateHistory(history) {
    if (!history.list || history.list.length === 0) {
        noHistory.style.display = 'block';
        historyList.style.display = 'none';
        return;
    }
    
    noHistory.style.display = 'none';
    historyList.style.display = 'block';
    historyList.innerHTML = '';
    
    // Sort by date (newest first)
    const sortedHistory = [...history.list].sort((a, b) => b.date - a.date);
    
    sortedHistory.forEach(item => {
        const date = new Date(item.date).toLocaleDateString();
        const type = item.reason === 'ADDED' ? 'added' : 'deleted';
        historyList.appendChild(createFriendItem(item, type, date));
    });
}

// Create friend item element
function createFriendItem(friend, type, date) {
    const item = document.createElement('div');
    item.className = 'friend-item';
    
    // Use better avatar fallback
    let avatar = './icons/ic_32.png'; // Default fallback
    if (friend.photo && friend.photo !== '' && friend.photo !== 'undefined') {
        avatar = friend.photo;
    } else if (friend.uid && friend.uid !== '' && friend.uid !== 'undefined') {
        avatar = getFacebookAvatar(friend.uid);
    }
    
    const name = friend.name || 'Unknown User';
    const badgeText = type === 'added' ? 'Added' : 'Deleted';
    
    item.innerHTML = `
        <img src="${avatar}" alt="${name}" class="friend-avatar" loading="lazy" onerror="this.src='./icons/ic_32.png'">
        <div class="friend-info">
            <div class="friend-name">${name}</div>
            <div class="friend-date">${date}</div>
        </div>
        <div class="friend-badge ${type}">${badgeText}</div>
    `;
    
    return item;
}

// Show specific tab
function showTab(tabName) {
    // Update tab buttons
    tabBtns.forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabName);
    });
    
    // Update tab content
    changesTab.classList.toggle('active', tabName === 'changes');
    historyTab.classList.toggle('active', tabName === 'history');
}

// Update last check time
function updateLastCheck() {
    const now = new Date().toLocaleTimeString();
    lastCheck.textContent = now;
}

// Handle errors gracefully
window.addEventListener('error', (event) => {
    console.error('Popup error:', event.error);
    userStatus.textContent = 'An error occurred. Please refresh.';
});

// Handle image loading errors
document.addEventListener('error', (event) => {
    if (event.target.tagName === 'IMG') {
        event.target.src = './icons/ic_32.png';
    }
}, true);