// DOM Elements
const userAvatar = document.getElementById('user-avatar');
const username = document.getElementById('username');
const userStatus = document.getElementById('user-status');
const totalFriends = document.getElementById('total-friends');
const addedCount = document.getElementById('added-count');
const deletedCount = document.getElementById('deleted-count');
const lastCheck = document.getElementById('last-check');

const changesTab = document.getElementById('changes-tab');
const historyTab = document.getElementById('history-tab');
const noChanges = document.getElementById('no-changes');
const changesList = document.getElementById('changes-list');
const noHistory = document.getElementById('no-history');
const historyList = document.getElementById('history-list');

const addedSection = document.getElementById('added-section');
const deletedSection = document.getElementById('deleted-section');
const addedListEl = document.getElementById('added-list');
const deletedListEl = document.getElementById('deleted-list');

const refreshBtn = document.getElementById('refresh-btn');
const clearBtn = document.getElementById('clear-btn');
const tabBtns = document.querySelectorAll('.tab-btn');

// Access token for Facebook Graph API (backup)
const FB_ACCESS_TOKEN = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662";

// Alternative Graph API approach without token
const getFacebookAvatar = (uid) => {
    // Try multiple avatar URLs
    const avatarUrls = [
        `https://graph.facebook.com/${uid}/picture?type=square&width=50&height=50`,
        `https://graph.facebook.com/${uid}/picture?type=small`,
        `https://graph.facebook.com/${uid}/picture`,
        `https://www.facebook.com/tr?id=${uid}&ev=PageView&noscript=1`
    ];
    
    return avatarUrls[0]; // Use first as primary
};

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
    await loadUserData();
    setupEventListeners();
    showTab('changes'); // Default tab
});

// Event Listeners
function setupEventListeners() {
    // Tab switching
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.dataset.tab;
            showTab(tabName);
        });
    });

    // Refresh button
    refreshBtn.addEventListener('click', async () => {
        refreshBtn.disabled = true;
        refreshBtn.innerHTML = '🔄 Scanning... <span class="loading"></span>';
        userStatus.textContent = 'Deep scanning friends list...';
        
        try {
            // Send message to background to check now
            await chrome.runtime.sendMessage({ action: 'CheckNow' });
            
            // Wait a bit longer for the improved scanning
            await new Promise(resolve => setTimeout(resolve, 2000));
            await loadUserData();
            userStatus.textContent = 'Scan completed!';
        } catch (error) {
            console.error('Error checking:', error);
            userStatus.textContent = 'Error during scan. Try again.';
        } finally {
            refreshBtn.disabled = false;
            refreshBtn.innerHTML = '🔄 Deep Scan';
        }
    });

    // Clear history button
    clearBtn.addEventListener('click', async () => {
        if (confirm('Are you sure you want to clear all history?')) {
            try {
                await chrome.storage.local.set({ 
                    history: { list: [] },
                    pending: { added: [], deleted: [], friendsTemp: {} }
                });
                await loadUserData();
                userStatus.textContent = 'History cleared';
            } catch (error) {
                console.error('Error clearing history:', error);
            }
        }
    });
}

// Load user data from background
async function loadUserData() {
    try {
        // Get data from background script
        const response = await chrome.runtime.sendMessage({ action: 'GetResults' });
        
        console.log('Extension response:', response); // Debug log
        
        if (!response || !response.payload) {
            console.log('No payload found, checking if user is logged in...');
            showLoginRequired();
            return;
        }

        console.log('User payload:', response.payload); // Debug log
        updateUserInfo(response.payload);
        updateStats(response);
        updateChanges(response.pending || {});
        updateHistory(response.history || { list: [] });
        updateLastCheck();
        
    } catch (error) {
        console.error('Error loading data:', error);
        showError();
    }
}

// Show login required message
function showLoginRequired() {
    console.log('User not logged in to Facebook');
    username.textContent = 'Please log in to Facebook';
    userStatus.textContent = 'Open Facebook in a new tab and log in';
    userAvatar.src = './icons/ic_48.png';
    
    // Show no data messages
    noChanges.querySelector('p').textContent = 'Please log in to Facebook first';
    noChanges.querySelector('small').textContent = 'Open facebook.com and log in, then click Deep Scan';
    
    noHistory.querySelector('p').textContent = 'Please log in to Facebook';
    noHistory.querySelector('small').textContent = 'History will be available after logging in';
    
    // Add login button functionality
    refreshBtn.innerHTML = '🔓 Login Required';
    refreshBtn.onclick = () => {
        chrome.tabs.create({ url: 'https://facebook.com' });
    };
}

// Show error message
function showError() {
    username.textContent = 'Error';
    userStatus.textContent = 'Unable to load data. Please try again.';
    userAvatar.src = './icons/ic_48.png';
}

// Update user info
function updateUserInfo(payload) {
    console.log('Updating user info with payload:', payload);
    
    username.textContent = payload.name || 'Unknown User';
    userStatus.textContent = 'Monitoring Facebook changes';
    
    // Try multiple avatar sources with fallback chain
    if (payload.photo && payload.photo !== '' && payload.photo !== 'undefined') {
        console.log('Using payload photo:', payload.photo);
        userAvatar.src = payload.photo;
    } else if (payload.uid && payload.uid !== '' && payload.uid !== 'undefined') {
        console.log('Using Facebook Graph API for UID:', payload.uid);
        // Try without access token first (more reliable)
        userAvatar.src = getFacebookAvatar(payload.uid);
    } else {
        console.log('No avatar source available, using default icon');
        userAvatar.src = './icons/ic_48.png';
    }
    
    // Handle avatar load errors with fallback chain
    userAvatar.onerror = function() {
        console.log('Avatar failed to load:', this.src);
        
        // If Graph API failed, try with access token
        if (this.src.includes('graph.facebook.com') && !this.src.includes('access_token') && payload.uid) {
            console.log('Trying with access token...');
            this.src = `https://graph.facebook.com/${payload.uid}/picture?type=square&access_token=${FB_ACCESS_TOKEN}`;
        } else {
            console.log('All avatar sources failed, using default icon');
            this.src = './icons/ic_48.png';
            // Prevent infinite loop
            this.onerror = null;
        }
    };
}

// Update stats
function updateStats(data) {
    const { payload, pending } = data;
    
    if (payload && payload.friends) {
        const detectedCount = Object.keys(payload.friends).length;
        totalFriends.textContent = detectedCount;
        
        // Add tooltip hint about potential difference
        totalFriends.parentElement.title = `Detected friends: ${detectedCount}\nNote: May differ from Facebook count due to privacy settings`;
    } else {
        totalFriends.textContent = '0';
    }
    
    if (pending) {
        addedCount.textContent = pending.added ? pending.added.length : 0;
        deletedCount.textContent = pending.deleted ? pending.deleted.length : 0;
    } else {
        addedCount.textContent = '0';
        deletedCount.textContent = '0';
    }
}

// Update changes tab
function updateChanges(pending) {
    const hasAdded = pending.added && pending.added.length > 0;
    const hasDeleted = pending.deleted && pending.deleted.length > 0;
    
    if (!hasAdded && !hasDeleted) {
        noChanges.style.display = 'block';
        changesList.style.display = 'none';
        return;
    }
    
    noChanges.style.display = 'none';
    changesList.style.display = 'block';
    
    // Show added friends
    if (hasAdded) {
        addedSection.style.display = 'block';
        addedListEl.innerHTML = '';
        
        pending.added.forEach(uid => {
            const friend = pending.friendsTemp && pending.friendsTemp[uid];
            if (friend) {
                addedListEl.appendChild(createFriendItem(friend, 'added', 'Just now'));
            }
        });
    } else {
        addedSection.style.display = 'none';
    }
    
    // Show deleted friends
    if (hasDeleted) {
        deletedSection.style.display = 'block';
        deletedListEl.innerHTML = '';
        
        pending.deleted.forEach(uid => {
            // Get friend info from main friends list
            const friend = { uid, name: 'Unknown User', photo: './icons/ic_32.png' };
            deletedListEl.appendChild(createFriendItem(friend, 'deleted', 'Just now'));
        });
    } else {
        deletedSection.style.display = 'none';
    }
}

// Update history tab
function updateHistory(history) {
    if (!history.list || history.list.length === 0) {
        noHistory.style.display = 'block';
        historyList.style.display = 'none';
        return;
    }
    
    noHistory.style.display = 'none';
    historyList.style.display = 'block';
    historyList.innerHTML = '';
    
    // Sort by date (newest first)
    const sortedHistory = [...history.list].sort((a, b) => b.date - a.date);
    
    sortedHistory.forEach(item => {
        const date = new Date(item.date).toLocaleDateString();
        const type = item.reason === 'ADDED' ? 'added' : 'deleted';
        historyList.appendChild(createFriendItem(item, type, date));
    });
}

// Create friend item element
function createFriendItem(friend, type, date) {
    const item = document.createElement('div');
    item.className = 'friend-item';
    
    // Use better avatar fallback
    let avatar = './icons/ic_32.png'; // Default fallback
    if (friend.photo && friend.photo !== '' && friend.photo !== 'undefined') {
        avatar = friend.photo;
    } else if (friend.uid && friend.uid !== '' && friend.uid !== 'undefined') {
        avatar = getFacebookAvatar(friend.uid);
    }
    
    const name = friend.name || 'Unknown User';
    const badgeText = type === 'added' ? 'Added' : 'Deleted';
    
    item.innerHTML = `
        <img src="${avatar}" alt="${name}" class="friend-avatar" loading="lazy" onerror="this.src='./icons/ic_32.png'">
        <div class="friend-info">
            <div class="friend-name">${name}</div>
            <div class="friend-date">${date}</div>
        </div>
        <div class="friend-badge ${type}">${badgeText}</div>
    `;
    
    return item;
}

// Show specific tab
function showTab(tabName) {
    // Update tab buttons
    tabBtns.forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabName);
    });
    
    // Update tab content
    changesTab.classList.toggle('active', tabName === 'changes');
    historyTab.classList.toggle('active', tabName === 'history');
}

// Update last check time
function updateLastCheck() {
    const now = new Date().toLocaleTimeString();
    lastCheck.textContent = now;
}

// Handle errors gracefully
window.addEventListener('error', (event) => {
    console.error('Popup error:', event.error);
    userStatus.textContent = 'An error occurred. Please refresh.';
});

// Handle image loading errors
document.addEventListener('error', (event) => {
    if (event.target.tagName === 'IMG') {
        event.target.src = './icons/ic_32.png';
    }
}, true);